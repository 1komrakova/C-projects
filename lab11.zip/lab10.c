#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "f.h"

int main(){
	int count = 3;
	int a = sum(count, 1, 2, 3);
	int b = max(count, 1, 2, 3);
	int c = min(count, 1, 2, 3);
	double d = average(count, 1, 2, 3);
	printf("%d %d %d %.2lf", a, b, c, d);
	return 0;
}
